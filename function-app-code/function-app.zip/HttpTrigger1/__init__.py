import logging
import azure.functions as func

def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('HTTP trigger function processed a request.')

    name = req.params.get('name')
    if not name:
        try:
            req_body = req.get_json()
            name = req_body.get('name')
        except:
            name = None

    if name:
        return func.HttpResponse(
            f"Hello, {name}! Azure Function is running successfully!",
            status_code=200
        )
    else:
        return func.HttpResponse(
            "Hello! Pass ?name=YourName",
            status_code=200
        )
