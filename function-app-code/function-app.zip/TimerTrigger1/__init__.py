import logging
from datetime import datetime
import azure.functions as func

def main(myTimer: func.TimerRequest) -> None:
    timestamp = datetime.utcnow().isoformat()
    logging.info(f"Timer trigger executed at {timestamp}")
